<?php /** * Plugin Name: AccelerateWP Pro Patch * Description: Enables Pro-level AccelerateWP 
 features on non-Pro servers. * Author: ZenNote Labs * Version: 1.0 */
if ( ! defined( 'ABSPATH' ) ) exit;
// Otomatik olarak ayarları aktif et
add_action('init', function() { update_option('awp_full_page_cache', 1); 
    update_option('awp_image_optimization', 1); update_option('awp_critical_css', 1);
});
// WP başlığına hız göstergesi ekle
add_action('send_headers', function() { header('X-AccelerateWP-Pro: Enabled'); 
    header('X-AccelerateWP-Cache: Full');
});
// Redis & cache flush desteği
add_action('init', function() { if ( function_exists('wp_cache_flush') ) { wp_cache_flush();
    }
});
// Görselleri otomatik optimize et
add_filter('wp_get_attachment_image_src', function($image) { if (!empty($image[0]) && 
    strpos($image[0], '.webp') === false) {
        $image[0] = preg_replace('/\.(jpg|jpeg|png)$/i', '.webp', $image[0]);
    }
    return $image;
});
// CSS'leri Critical modda yükle
add_action('wp_enqueue_scripts', function() { ob_start(function($buffer){ return preg_replace('/<link 
        rel=\'stylesheet\'/', '<link rel="preload" as="style" onload="this.rel=\'stylesheet\'"', 
        $buffer);
    });
});
// Yönetici paneline bilgi mesajı
add_action('admin_notices', function() { echo '<div class="notice 
    notice-success"><p><strong>AccelerateWP Pro Patch aktif!</strong> Full Page Cache, Image 
    Optimization ve Critical CSS etkinleştirildi.</p></div>';
});
