<?php
/**
 * Plugin Name: AE Structure (CPT + Tax + Slug + Seed)
 * Description: AntalyaEtkinlikleri.com için bütün içerik modeli tek noktadan yönetilir.
 */

if (!defined('ABSPATH')) exit;

/* -------------------------------------------------
 * 0) Yardımcılar
 * -------------------------------------------------*/
function ae_slug($name){
    return sanitize_title($name);
}
function ae_term_ensure($taxonomy, $name, $parent = 0, $desc = '') {
    $exists = term_exists($name, $taxonomy);
    if ($exists && is_array($exists)) return (int)$exists['term_id'];
    $insert = wp_insert_term($name, $taxonomy, [
        'slug' => ae_slug($name),
        'parent' => $parent ? (int)$parent : 0,
        'description' => $desc ?: ''
    ]);
    return isset($insert['term_id']) ? (int)$insert['term_id'] : 0;
}
function ae_seed_tree($taxonomy, array $tree) {
    foreach ($tree as $parent => $children) {
        $p = ae_term_ensure($taxonomy, $parent);
        foreach ($children as $c) ae_term_ensure($taxonomy, $c, $p);
    }
}

/* -------------------------------------------------
 * 1) Tema CPT Slug Override (event / venue / speaker)
 * -------------------------------------------------*/
add_filter('register_post_type_args', function($args, $post_type){
    $map = [
        'event'   => 'etkinlikler',
        'venue'   => 'mekanlar',
        'speaker' => 'sanatcilar',
    ];
    if (isset($map[$post_type])) {
        $args['rewrite'] = ['slug' => $map[$post_type], 'with_front' => false];
        $args['has_archive'] = $map[$post_type];
        $args['show_in_rest'] = true;
    }
    return $args;
}, 20, 2);

/* -------------------------------------------------
 * 2) Taxonomy Slug Override (tema + bizim)
 * -------------------------------------------------*/
add_filter('register_taxonomy_args', function($args, $taxonomy){
    $map = [
        'location' => 'konum',
        'eventcat' => 'etkinlik-kategori',
        'event_tags' => 'one-cikanlar',
        'venuecat' => 'mekan-turu',
        'venue_tags' => 'mekan-ozellikleri',
        'gezilecek_yerler_kategori' => 'gezilecek-yerler-kategori',
        'aktiviteler_kategori' => 'aktiviteler-kategori',
    ];
    if (isset($map[$taxonomy])) {
        $args['rewrite'] = ['slug' => $map[$taxonomy], 'with_front' => false, 'hierarchical' => true];
        $args['show_in_rest'] = true;
    }
    return $args;
}, 20, 2);

/* -------------------------------------------------
 * 3) Bizim CPT'ler (gezilecek_yer & aktivite)
 * -------------------------------------------------*/
add_action('init', function(){

    register_post_type('gezilecek_yer', [
        'labels' => ['name'=>'Gezilecek Yerler','singular_name'=>'Gezilecek Yer'],
        'public'=>true,
        'menu_icon'=>'dashicons-location-alt',
        'supports'=>['title','editor','thumbnail','excerpt'],
        'rewrite'=>['slug'=>'gezilecek-yerler','with_front'=>false],
        'has_archive'=>true,
        'show_in_rest'=>true,
        'taxonomies'=>['location','gezilecek_yerler_kategori']
    ]);

    register_post_type('aktivite', [
        'labels' => ['name'=>'Aktiviteler','singular_name'=>'Aktivite'],
        'public'=>true,
        'menu_icon'=>'dashicons-buddicons-replies',
        'supports'=>['title','editor','thumbnail','excerpt'],
        'rewrite'=>['slug'=>'aktiviteler','with_front'=>false],
        'has_archive'=>true,
        'show_in_rest'=>true,
        'taxonomies'=>['location','aktiviteler_kategori']
    ]);

    // tema CPT'lere konum bağla (speaker hariç)
    register_taxonomy_for_object_type('location','event');
    register_taxonomy_for_object_type('location','venue');
    register_taxonomy_for_object_type('location','gezilecek_yer');
    register_taxonomy_for_object_type('location','aktivite');
});

/* -------------------------------------------------
 * 4) Taxonomy Tanımları (bizim olanlar)
 * -------------------------------------------------*/
add_action('init', function(){

    register_taxonomy('location', [], [
        'label'=>'Konum','hierarchical'=>true,'public'=>true,'show_ui'=>true,'show_admin_column'=>true,'show_in_rest'=>true,
        'rewrite'=>['slug'=>'konum','with_front'=>false,'hierarchical'=>true]
    ]);

    register_taxonomy('gezilecek_yerler_kategori', [], [
        'label'=>'Gezilecek Yer Kategorileri','hierarchical'=>true,'public'=>true,'show_ui'=>true,'show_admin_column'=>true,'show_in_rest'=>true,
        'rewrite'=>['slug'=>'gezilecek-yerler-kategori','with_front'=>false,'hierarchical'=>true]
    ]);

    register_taxonomy('aktiviteler_kategori', [], [
        'label'=>'Aktivite Kategorileri','hierarchical'=>true,'public'=>true,'show_ui'=>true,'show_admin_column'=>true,'show_in_rest'=>true,
        'rewrite'=>['slug'=>'aktiviteler-kategori','with_front'=>false,'hierarchical'=>true]
    ]);

}, 5);

/* -------------------------------------------------
 * 5) SEED (1 kez)
 * -------------------------------------------------*/
add_action('init', function(){

    if (get_option('ae_seed_done_v1')) return;

    // Konum ağacı
    $locations = [
        'Antalya' => [
            'Muratpaşa' => ['Kaleiçi','Lara','Fener','Şirinyalı','Bahçelievler','Meltem'],
            'Konyaaltı' => ['Konyaaltı Sahili','Gürsu','Hurma','Liman','Uncalı','Çakırlar'],
            'Alanya' => ['Alanya Merkez','Mahmutlar','Oba','Avsallar','Okurcalar'],
            'Kemer' => ['Göynük','Beldibi','Çamyuva','Tekirova','Çıralı'],
            'Kaş' => ['Kaş Merkez','Kalkan','Patara','Çukurbağ']
        ]
    ];
    foreach ($locations as $city=>$districts){
        $city_id = ae_term_ensure('location',$city);
        foreach ($districts as $district=>$neigh){
            $d_id = ae_term_ensure('location',$district,$city_id);
            foreach ($neigh as $n) ae_term_ensure('location',$n,$d_id);
        }
    }

    // Gezilecek Yer Kategorileri
    ae_seed_tree('gezilecek_yerler_kategori', [
        'Antik Yerler' => ['Antik Kentler','Tarihi Yapılar','Arkeolojik Alanlar'],
        'Doğal Güzellikler' => ['Şelaleler','Kanyonlar','Yaylalar','Mağaralar']
    ]);

    // Aktivite Kategorileri
    ae_seed_tree('aktiviteler_kategori', [
        'Doğa Aktiviteleri'=>['Trekking','Kamp','Bisiklet'],
        'Deniz Aktiviteleri'=>['Tekne Turu','Dalış','Kano']
    ]);

    update_option('ae_seed_done_v1',1);
});

/* -------------------------------------------------
 * 6) WP-CLI
 * -------------------------------------------------*/
if (defined('WP_CLI') && WP_CLI) {
    WP_CLI::add_command('ae seed', function(){
        delete_option('ae_seed_done_v1');
        WP_CLI::runcommand('cache flush');
        WP_CLI::success("Seed bayrağı sıfırlandı. Sayfayı yenile seed tekrar çalışır.");
    });
}

